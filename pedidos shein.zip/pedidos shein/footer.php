<footer>
<hr/>
Quejas y Sujerencias &copy; Con Paulina Tapia y Julisa Lizarraga <?=date("Y")?>

</footer>

</body>
</html>

