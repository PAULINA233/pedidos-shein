<!DOCTYPE html>
<html>
<head>

	<title>Registrar pedido</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
    <form method="post">
    	<h1>¡Suscribete!</h1>
    	<input type="text" name="name" placeholder="Prenda o Producto">
    	<input type="text" name="name" placeholder="Cantidades">
    	<input type="submit" name="register">
    </form>
        <?php 
		include("registrar.php");
		
		
		

		?>
</body>
</html>